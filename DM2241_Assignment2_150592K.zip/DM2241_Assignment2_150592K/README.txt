Controls:
UP arrow->move up.
DOWN arrow->move down.
RIGHT arrow->move rotate rightward.
LEFT arrow->move leftwards.

SPACE-> FIre bullets.
C -> Fire Homing Missiles when ready and acquired.

Touching the Red cross will give the player +50 health.
Touching the green cross will give the player a charge of missile if he doesnt have one.

A blackhole will spawn after 15Second which changes the trajectory of bullet and missiles.
Any projectile that touched the blackhole will be destroyed.

The timebomb will also spawn after 20 sec and will explose in 10 seconds. if the ship if in the
range, it will take damage.

Done:
Max Two players at once
Dead Reckoning for all moving objects (ships and projectiles)
Missiles does damage and know it's owner
Boom effect when there is a collision or explosion
Ship Health
Ship dies if healh less than 0

Added new weapon(changed the missile to a homing missile and add a gun that fires 3 shots)
Added a server spawning Powerups(one to get health and one to get a missile charge)
Added respawn of the ship after a certain period of time.

Added a server spawning blackhole that destroys any projectiles in contact and change
gravity of the projectiles.
Added a server spawning Time bomb that will detonate after some time and damage any ship
 in range.