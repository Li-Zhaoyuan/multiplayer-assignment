#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include "Application.h"

namespace Global
{
	extern Application* application;
};

#endif