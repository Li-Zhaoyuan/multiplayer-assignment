#ifndef CONFIG_H_
#define CONFIG_H_

#define DFL_SERVER_IP      "127.0.0.1"
#define DFL_PORTNUMBER     7890
#define DFL_MAX_CONNECTION 100

#endif